package com.example.cutoff;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }

    public void mediClick(View view) {
        int bio,phy,chem;
        float cutoff;
        EditText etBio = findViewById(R.id.etBio);
        EditText etPhy = findViewById(R.id.etPhy);
        EditText etChem = findViewById(R.id.etChem);
        bio=Integer.parseInt(etBio.getText().toString());
        phy=Integer.parseInt(etPhy.getText().toString());
        chem=Integer.parseInt(etChem.getText().toString());
        cutoff=(bio/2)+(phy/4)+(chem/4);

        TextView tvCutOff = findViewById(R.id.tvCutOff);
        tvCutOff.setText(String.valueOf(cutoff));
    }

    public void backClick(View view) {
        Intent intent=new Intent(this,Main3Activity.class);
        startActivity(intent);
    }
}
