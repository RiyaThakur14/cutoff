package com.example.cutoff;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Main7Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
    }

    public void backClick(View view) {
        Intent intent=new Intent(this,Main3Activity.class);
        startActivity(intent);

    }

    public void agriClick(View view) {
        int bio,math,phy,chem;
        float cutoff;
        EditText etmath = findViewById(R.id.etmath);
        EditText etphy = findViewById(R.id.etphy);
        EditText etchem = findViewById(R.id.etchem);
        EditText etBio = findViewById(R.id.etBio);
        math=Integer.parseInt(etmath.getText().toString());
        phy=Integer.parseInt(etphy.getText().toString());
        chem=Integer.parseInt(etchem.getText().toString());
        bio=Integer.parseInt(etBio.getText().toString());
        cutoff=(math/4)+(phy/4)+(chem/4)+(bio/4);

        TextView tvCutOff = findViewById(R.id.tvCutOff);
        tvCutOff.setText(String.valueOf(cutoff));
    }
}
