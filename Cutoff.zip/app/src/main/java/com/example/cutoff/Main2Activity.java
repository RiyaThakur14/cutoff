package com.example.cutoff;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void cutoffClick(View view) {
        int math,phy,chem;
        float cutoff;
        EditText etMath = findViewById(R.id.etMath);
        EditText etPhy = findViewById(R.id.etPhy);
        EditText etChem = findViewById(R.id.etChem);
        math=Integer.parseInt(etMath.getText().toString());
        phy=Integer.parseInt(etPhy.getText().toString());
        chem=Integer.parseInt(etChem.getText().toString());
        cutoff=(math/2)+(phy/4)+(chem/4);

        TextView tvCutOff = findViewById(R.id.tvCutOff);
        tvCutOff.setText(String.valueOf(cutoff));
    }

    public void backClick(View view) {
        Intent intent=new Intent(this,Main3Activity.class);
        startActivity(intent);
    }
}
